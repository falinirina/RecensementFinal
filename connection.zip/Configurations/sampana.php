<?php
    $sampana = array(
        0 => ["slk", "Sampana Lehilahy Kristianina", "SLK"],
        1 => ["dorkasy","Sampana Dorkasy", "Dorkasy"],
        2 => ["vfl","Sampana Vondrona Fototra Laika", "VFL"],
        3 => ["antemafi","Sampana Tanora Kristianina: ANTEMAFI", "Antemafi"],
        4 => ["akobe","Sampana Tanora Kristianina: AKOBE", "AKOBE"],
        5 => ["sbt","Sampana Tanora Kristianina: SBT", "SBT"],
        6 => ["safif","Sampana Fifohazana", "SAFIF"],
        7 => ["svm","Sampana Vokovoko Manga", "SVM"],
        8 => ["ssa","Sampana Sekoly Alahady", "SSA"],
        9 => ["smt","Sampana Mpanazava sy Tily", "SMT"],
        10 => ["saaff","Sampan’Asa Asa Fitoriana Filazantsara", "SAAFF"],
    );
?>